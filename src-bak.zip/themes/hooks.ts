import { useTheme } from '@/themes/context'

// 便捷的主题配置访问Hook
export const useThemeConfig = () => {
  const { theme, isDark } = useTheme()
  
  // 返回方便访问的配置对象
  return {
    // 整个主题对象
    theme,
    isDark,
    
    // 便捷访问器 - 按照用户要求的格式
    config: {
      // 背景色系列
      background: theme.colors.background,
      
      // 文字色系列
      text: theme.colors.text,
      
      // 边框色系列
      border: theme.colors.border,
      
      // 渐变色系列
      gradient: theme.colors.gradient,
      
      // 阴影色系列
      shadow: theme.colors.shadow,
      
      // 状态色系列
      status: theme.colors.status,
    },
    
    // 便捷的常用颜色访问
    colors: {
      // 常用背景色
      window: theme.colors.background.surface,     // 窗口背景色
      card: theme.colors.background.surface,       // 卡片背景色
      input: theme.colors.background.input,        // 输入框背景色
      overlay: theme.colors.background.overlay,     // 遮罩背景色
      
      // 常用文字色
      title: theme.colors.text.title,               // 标题颜色
      primary: theme.colors.text.primary,          // 主要文字颜色
      secondary: theme.colors.text.secondary,      // 次要文字颜色
      contrast: theme.colors.text.contrast,        // 高对比度文字颜色
      muted: theme.colors.text.muted,              // 弱化文字颜色
      link: theme.colors.text.link,                 // 链接颜色
      placeholder: theme.colors.text.placeholder,   // 占位符颜色
      
      // 常用边框色
      border: theme.colors.border.medium,          // 默认边框色
      focus: theme.colors.border.focus,             // 焦点边框色
      
      // 常用状态色
      success: theme.colors.status.success,         // 成功色
      warning: theme.colors.status.warning,         // 警告色
      error: theme.colors.status.error,            // 错误色
      info: theme.colors.status.info,               // 信息色
    }
  }
}

// 主题样式生成器 - 用于生成Tailwind类名
export const useThemeStyles = () => {
  const { config } = useThemeConfig()
  
  return {
    // 背景样式
    bg: {
      primary: `bg-[${config.background.primary}]`,
      secondary: `bg-[${config.background.secondary}]`,
      surface: `bg-[${config.background.surface}]`,
      input: `bg-[${config.background.input}]`,
      overlay: `bg-[${config.background.overlay}]`,
    },
    
    // 文字样式
    text: {
      title: `text-[${config.text.title}]`,
      primary: `text-[${config.text.primary}]`,
      secondary: `text-[${config.text.secondary}]`,
      contrast: `text-[${config.text.contrast}]`,
      muted: `text-[${config.text.muted}]`,
      link: `text-[${config.text.link}]`,
      placeholder: `text-[${config.text.placeholder}]`,
    },
    
    // 边框样式
    border: {
      light: `border-[${config.border.light}]`,
      medium: `border-[${config.border.medium}]`,
      focus: `border-[${config.border.focus}]`,
    }
  }
}