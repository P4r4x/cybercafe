// 导出所有主题相关的类型和函数
export * from './types'
export * from './light'
export * from './dark'
export * from './context'

// 主题工具函数
export const getThemeValue = (theme: any, path: string): string => {
  const keys = path.split('.')
  let value = theme
  
  for (const key of keys) {
    value = value?.[key]
    if (value === undefined) return ''
  }
  
  return value || ''
}

// 主题预设配置
export const themePresets = {
  light: {
    name: '日间模式',
    description: '明亮的日间主题，以白桃色、樱花色、橘色为主',
    icon: '☀️'
  },
  dark: {
    name: '夜间模式', 
    description: '深邃的夜间主题，以夜樱、深蓝、深紫色为主',
    icon: '🌙'
  },
  auto: {
    name: '自动模式',
    description: '跟随系统主题自动切换',
    icon: '🔄'
  }
} as const