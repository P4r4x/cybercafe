import React, { useState } from 'react'
import { useThemeConfig } from '@/themes/hooks'
import { Avatar } from '@/components/ui/SmartImage'
import { User, Star, Wallet } from 'lucide-react'

// 用户信息接口
interface UserInfo {
  uid: string
  username: string
  level: number
  exp: number
  exp_required: number
  balance: string
  avatar?: string // 用户头像URL（可选）
}

// 账户简介组件的Props
interface AccountProfileProps {
  userInfo: UserInfo
}

export const AccountProfile: React.FC<AccountProfileProps> = ({ userInfo }) => {
  const { colors } = useThemeConfig()
  const [showBalance, setShowBalance] = useState(false)
  const [showExpDetails, setShowExpDetails] = useState(false)

  // 计算经验值进度
  const expProgress = (userInfo.exp / userInfo.exp_required) * 100
  
  // 格式化余额，保留两位小数
  const formatBalance = (balance: string) => {
    const num = parseFloat(balance)
    return num.toFixed(2)
  }

  return (
    <div 
      className="p-6 rounded-xl shadow-lg"
      style={{ 
        backgroundColor: colors.card,
        border: `1px solid ${colors.border}`
      }}
    >
      {/* 头像和基本信息 */}
      <div className="flex flex-col items-center mb-6">
        {/* 头像 - 使用智能图片组件 */}
        <Avatar
          src={userInfo.avatar}
          alt="用户头像"
          width={80}
          height={80}
          className="mb-4"
        />

        {/* UID和用户名 */}
        <div className="text-center">
          <p className="text-sm mb-1" style={{ color: colors.secondary }}>
            UID: {userInfo.uid}
          </p>
          <h3 style={{ color: colors.title }} className="text-xl font-semibold">
            {userInfo.username}
          </h3>
        </div>
      </div>

      {/* 账户等级和经验值 */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Star className="w-4 h-4" style={{ color: '#F59E0B' }} />
            <span className="font-medium" style={{ color: colors.primary }}>
              Lv.{userInfo.level}
            </span>
          </div>
          <span 
            className="text-sm px-2 py-1 rounded-md"
            style={{ 
              backgroundColor: colors.input,
              color: colors.secondary
            }}
          >
            经验值
          </span>
        </div>

        {/* 经验值进度条 - hover显示详情 */}
        <div 
          className="relative"
          onMouseEnter={() => setShowExpDetails(true)}
          onMouseLeave={() => setShowExpDetails(false)}
        >
          {/* 进度条 */}
          <div className="mb-2">
            <div 
              className="w-full h-3 rounded-full overflow-hidden cursor-help transition-all duration-200 hover:shadow-md"
              style={{ backgroundColor: colors.input }}
            >
              <div 
                className="h-full transition-all duration-500 ease-out"
                style={{ 
                  width: `${Math.min(expProgress, 100)}%`,
                  backgroundColor: '#48BB78'
                }}
              />
            </div>
          </div>

          {/* 平时只显示进度百分比 */}
          <div 
            className="text-center text-sm font-mono transition-opacity duration-200"
            style={{ 
              color: colors.secondary,
              opacity: showExpDetails ? 0 : 1
            }}
          >
            {Math.round(expProgress)}%
          </div>

          {/* hover时显示详细经验值 */}
          {showExpDetails && (
            <div 
              className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 rounded-lg shadow-lg z-10 whitespace-nowrap"
              style={{ 
                backgroundColor: colors.card,
                border: `1px solid ${colors.border}`
              }}
            >
              <div className="text-sm text-center">
                <p style={{ color: colors.secondary }} className="mb-1">
                  当前经验 / 升级所需
                </p>
                <p 
                  className="font-mono font-bold"
                  style={{ color: colors.primary }}
                >
                  {userInfo.exp} / {userInfo.exp_required}
                </p>
                <p 
                  className="text-xs mt-1"
                  style={{ color: '#48BB78' }}
                >
                  还需 {Math.max(0, userInfo.exp_required - userInfo.exp)} 经验升级
                </p>
              </div>
              {/* 小三角 */}
              <div 
                className="absolute top-full left-1/2 transform -translate-x-1/2 -translate-y-1/2 rotate-45 w-2 h-2"
                style={{ backgroundColor: colors.card }}
              />
            </div>
          )}
        </div>
      </div>

      {/* 账户余额 - hover显示详情 */}
      <div className="relative">
        <button
          onMouseEnter={() => setShowBalance(true)}
          onMouseLeave={() => setShowBalance(false)}
          className="w-full flex items-center justify-between p-4 rounded-lg transition-all duration-200 hover:shadow-md"
          style={{ 
            backgroundColor: colors.input,
            border: `1px solid ${colors.border}`
          }}
        >
          <div className="flex items-center gap-3">
            <Wallet className="w-5 h-5" style={{ color: colors.secondary }} />
            <span style={{ color: colors.primary }} className="font-medium">
              账户余额
            </span>
          </div>
          <span style={{ color: colors.contrast }} className="font-mono">
            ¥{formatBalance(userInfo.balance)}
          </span>
        </button>

        {/* 余额详情子窗 */}
        {showBalance && (
          <div 
            className="absolute bottom-full left-0 right-0 mb-2 p-3 rounded-lg shadow-lg z-10"
            style={{ 
              backgroundColor: colors.card,
              border: `1px solid ${colors.border}`
            }}
          >
            <div className="text-sm">
              <p style={{ color: colors.secondary }} className="mb-1">
                可用余额
              </p>
              <p 
                className="text-lg font-bold"
                style={{ color: '#48BB78' }}
              >
                ¥{formatBalance(userInfo.balance)}
              </p>
            </div>
            {/* 小三角 */}
            <div 
              className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1/2 rotate-45 w-2 h-2"
              style={{ backgroundColor: colors.card }}
            />
          </div>
        )}
      </div>
    </div>
  )
}