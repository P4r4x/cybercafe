import React from 'react'
import { BookshelfItemDTO } from '@/types/bookshelf'
import { useThemeConfig } from '@/themes/hooks'
import { BookCover } from '@/components/ui/SmartImage'

interface BookCardProps {
  book: BookshelfItemDTO
  onClick?: (book: BookshelfItemDTO) => void
}

export const BookCard: React.FC<BookCardProps> = ({ book, onClick }) => {
  const { config } = useThemeConfig()

  return (
    <div
      className="p-4 rounded-lg cursor-pointer transition-all duration-200 hover:scale-105 hover:shadow-lg"
      style={{
        backgroundColor: config.background.surface,
        border: `1px solid ${config.border.light}`
      }}
      onClick={() => onClick?.(book)}
    >
      <div className="aspect-[3/4] mb-3 rounded-lg overflow-hidden">
        <BookCover
          src={book.cover_url}
          alt={book.Title}
          width="100%"
          height="100%"
          className="w-full h-full"
          fallback={
            <div className="w-full h-full bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center">
              <div className="text-white text-4xl font-bold">
                {book.Title.charAt(0).toUpperCase()}
              </div>
            </div>
          }
        />
      </div>
      
      <h3
        className="font-semibold text-sm mb-1 truncate"
        style={{ color: config.text.primary }}
      >
        {book.Title}
      </h3>
      
      <p
        className="text-xs truncate"
        style={{ color: config.text.secondary }}
      >
        {book.Author}
      </p>
    </div>
  )
}