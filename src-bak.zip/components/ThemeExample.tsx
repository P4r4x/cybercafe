import React from 'react'
import { useThemeConfig } from '@/themes/hooks'

// 备忘组件：防止忘记调用写的示例组件, 展示如何使用主题配置
export const ThemeExample: React.FC = () => {
  const { config, colors } = useThemeConfig()

  return (
    <div 
      className="p-6 rounded-lg"
      style={{ 
        backgroundColor: config.background.surface,
        border: `2px solid ${config.border.medium}`,
        boxShadow: `0 4px 6px ${config.shadow.medium}`
      }}
    >
      <h2 style={{ color: config.text.title }}>
        主题配置示例
      </h2>
      <p style={{ color: config.text.primary }}>
        使用 config.background.surface 背景色
      </p>
      <p style={{ color: config.text.secondary }}>
        使用 config.text.secondary 文字色
      </p>
      <div 
        className="mt-4 px-4 py-2 rounded"
        style={{ 
          background: config.gradient.primary,
          color: config.text.contrast 
        }}
      >
        渐变背景 + 高对比度文字
      </div>
    </div>
  )
}

// 简化使用示例
export const SimpleExample: React.FC = () => {
  const { colors } = useThemeConfig()

  return (
    <div style={{ backgroundColor: colors.window }}>
      <h1 style={{ color: colors.title }}>标题颜色</h1>
      <p style={{ color: colors.primary }}>主要文字颜色</p>
      <input 
        placeholder="输入框"
        style={{
          backgroundColor: colors.input,
          color: colors.contrast,
          border: `1px solid ${colors.border}`
        }}
      />
      <button style={{ color: colors.link }}>链接按钮</button>
    </div>
  )
}