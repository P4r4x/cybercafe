// 主题类型定义
export interface ThemeColors {
  // 背景色系列 - 10种不同用途的背景色
  background: {
    primary: string      // 主背景色
    secondary: string    // 次要背景色
    accent: string       // 强调背景色
    surface: string      // 表面/卡片背景色
    overlay: string      // 遮罩背景色
    input: string        // 输入框背景色
    button: string       // 按钮背景色
    success: string      // 成功状态背景色
    warning: string      // 警告状态背景色
    error: string        // 错误状态背景色
  }

  // 文字色系列
  text: {
    primary: string       // 主要文字色
    secondary: string     // 次要文字色
    title: string         // 标题文字色
    contrast: string      // 高对比度文字色
    muted: string         // 弱化文字色
    inverse: string       // 反色文字色(用于深色背景)
    link: string          // 链接文字色
    placeholder: string    // 占位符文字色
    code: string          // 代码文字色
    caption: string       // 说明文字色
  }

  // 边框色系列
  border: {
    light: string         // 浅边框色
    medium: string        // 中等边框色
    dark: string          // 深边框色
    focus: string         // 焦点边框色
    error: string         // 错误边框色
    success: string       // 成功边框色
  }

  // 渐变色系列 - 符合设计要求
  gradient: {
    primary: string       // 主渐变色 (白桃色/樱花色/橘色)
    secondary: string     // 次要渐变色
    accent: string        // 强调渐变色
    night: string         // 夜间渐变色 (夜樱/深蓝/深紫色)
    background: string    // 背景渐变色
  }

  // 阴影色系列
  shadow: {
    light: string         // 浅阴影
    medium: string       // 中等阴影
    dark: string          // 深阴影
    colored: string       // 彩色阴影
  }

  // 状态色系列
  status: {
    info: string          // 信息色
    success: string       // 成功色
    warning: string      // 警告色
    error: string        // 错误色
    loading: string       // 加载色
  }
}

// 主题配置接口
export interface Theme {
  name: string
  type: 'light' | 'dark'
  colors: ThemeColors
}

// 主题上下文接口
export interface ThemeContextType {
  theme: Theme
  isDark: boolean
  toggleTheme: () => void
  setTheme: (theme: Theme) => void
}

// 主题预设名称
export type ThemePreset = 'light' | 'dark' | 'auto'