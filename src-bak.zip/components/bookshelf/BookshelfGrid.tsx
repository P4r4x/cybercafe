import React, { useState, useEffect } from 'react'
import { BookCard } from './BookCard'
import { BookshelfItemDTO } from '@/types/bookshelf'
import { useThemeConfig } from '@/themes/hooks'
import { useApi } from '@/hooks/useApi'

interface BookshelfGridProps {
  onBookClick?: (book: BookshelfItemDTO) => void
}

export const BookshelfGrid: React.FC<BookshelfGridProps> = ({ onBookClick }) => {
  const { config } = useThemeConfig()
  const { get } = useApi()

  const [allBooks, setAllBooks] = useState<BookshelfItemDTO[]>([])
  const [displayedBooks, setDisplayedBooks] = useState<BookshelfItemDTO[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [currentPage, setCurrentPage] = useState(1)
  const [hasMore, setHasMore] = useState(true)

  const pageSize = 6

  const fetchAllBooks = async () => {
    setLoading(true)
    setError(null)
    
    try {
      const data: BookshelfItemDTO[] = await get('/me/bookshelf')
      setAllBooks(data)
      
      // 初始化第一页数据
      const firstPageBooks = data.slice(0, pageSize)
      setDisplayedBooks(firstPageBooks)
      setHasMore(data.length > pageSize)
      setCurrentPage(1)
    } catch (err) {
      setError(err instanceof Error ? err.message : '未知错误')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchAllBooks()
  }, [])

  const handleLoadMore = () => {
    if (!loading && hasMore) {
      const nextPage = currentPage + 1
      const startIndex = (nextPage - 1) * pageSize
      const endIndex = startIndex + pageSize
      const nextBooks = allBooks.slice(startIndex, endIndex)
      
      setDisplayedBooks(prev => [...prev, ...nextBooks])
      setCurrentPage(nextPage)
      setHasMore(endIndex < allBooks.length)
    }
  }

  const handleRefresh = () => {
    fetchAllBooks()
  }

  if (error) {
    return (
      <div className="text-center py-8">
        <div
          className="inline-block p-4 rounded-lg mb-4"
          style={{ backgroundColor: config.background.surface }}
        >
          <div className="text-2xl mb-2">😞</div>
          <p style={{ color: config.text.secondary }}>{error}</p>
        </div>
        <button
          onClick={handleRefresh}
          className="px-4 py-2 rounded-lg transition-colors duration-200"
          style={{ backgroundColor: config.status.info, color: 'white' }}
        >
          重试
        </button>
      </div>
    )
  }

  if (loading && displayedBooks.length === 0) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {Array.from({ length: 6 }).map((_, index) => (
          <div
            key={index}
            className="p-4 rounded-lg animate-pulse"
            style={{ backgroundColor: config.background.surface }}
          >
            <div
              className="aspect-[3/4] mb-3 rounded-lg"
              style={{ backgroundColor: config.background.secondary }}
            />
            <div
              className="h-4 rounded mb-2 animate-pulse"
              style={{ backgroundColor: config.background.secondary }}
            />
            <div
              className="h-3 rounded w-3/4 animate-pulse"
              style={{ backgroundColor: config.background.secondary }}
            />
          </div>
        ))}
      </div>
    )
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2
            className="text-lg font-semibold"
            style={{ color: config.text.primary }}
          >
            我的书架
          </h2>
          <p
            className="text-sm"
            style={{ color: config.text.secondary }}
          >
            共 {allBooks.length} 本书
          </p>
        </div>
        
        <button
          onClick={handleRefresh}
          className="p-2 rounded-lg transition-colors duration-200"
          style={{ backgroundColor: config.background.surface }}
        >
          🔄
        </button>
      </div>

{displayedBooks.length === 0 ? (
        <div className="text-center py-8">
          <div
            className="inline-block p-4 rounded-lg mb-4"
            style={{ backgroundColor: config.background.surface }}
          >
            <div className="text-2xl mb-2">📚</div>
            <p style={{ color: config.text.secondary }}>书架还是空的</p>
          </div>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
            {displayedBooks.map((book) => (
              <BookCard
                key={book.BookID}
                book={book}
                onClick={onBookClick}
              />
            ))}
          </div>

          {hasMore && (
            <div className="text-center">
              <button
                onClick={handleLoadMore}
                disabled={loading}
                className="px-6 py-2 rounded-lg transition-colors duration-200 disabled:opacity-50"
                style={{ backgroundColor: config.status.info, color: 'white' }}
              >
                {loading ? '加载中...' : '加载更多'}
              </button>
            </div>
          )}
        </>
      )}
    </div>
  )
}