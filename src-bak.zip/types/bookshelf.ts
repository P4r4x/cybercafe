import React from 'react'

export interface BookshelfItemDTO {
  BookID: string
  Title: string
  Author: string
  cover_url?: string // 图书封面URL（可选）
}