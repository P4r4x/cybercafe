import React from 'react'
import { useLocation } from 'react-router-dom'
import { Sidebar } from './Sidebar'

interface MainLayoutProps {
  children: React.ReactNode
}

export const MainLayout: React.FC<MainLayoutProps> = ({ children }) => {
  const location = useLocation()
  const isHomePage = location.pathname === '/home'

  return (
    
    <div className="h-screen overflow-hidden group relative">
      {/* Animated grid background */}
      <div className="absolute inset-0 opacity-15 pointer-events-none overflow-hidden">
        <div 
          className="absolute inset-0 animate-grid-drift"
          style={{
            backgroundImage: `
              linear-gradient(45deg, rgba(156, 163, 175, 0.1) 1px, transparent 1px),
              linear-gradient(-45deg, rgba(156, 163, 175, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: '60px 60px',
            width: '200%',
            height: '200%'
          }}
        ></div>
      </div>

      {/* 侧边栏 */}
      <Sidebar />
      
      {/* 主内容区域 - 在homepage时隐藏margin边框 */}
      <div 
        className={`h-screen overflow-y-auto transition-all duration-300 ease-out relative ${
          isHomePage 
            ? '' 
            : 'ml-16 group-hover:ml-60'
        }`}
        style={isHomePage ? {} : { marginLeft: '64px' }}
      >
        <main className={`relative bg-transparent ${
          isHomePage ? '' : 'p-6'
        }`}>
          {children}
        </main>
      </div>
    </div>
  )
}