import React from 'react'
import { MainLayout } from '@/components/layout'
import { useThemeConfig } from '@/themes/hooks'
import { useTheme } from '@/themes'
import { useToast } from '@/components/ui'

export default function ToastDemoPage() {
  const { config } = useThemeConfig()
  const { toggleTheme } = useTheme()
  const { success, error, warning, info } = useToast()

  const handleShowToast = (type: 'success' | 'error' | 'warning' | 'info') => {
    const messages = {
      success: [
        '操作成功完成！',
        '保存成功！',
        '登录成功！',
        '上传完成！'
      ],
      error: [
        '网络连接失败，请检查网络设置',
        '服务器响应超时，请稍后重试',
        '权限不足，无法执行此操作',
        '数据验证失败，请检查输入内容'
      ],
      warning: [
        '请注意：此操作不可撤销',
        '警告：存储空间不足',
        '提醒：密码即将过期',
        '注意：当前版本较旧，建议更新'
      ],
      info: [
        '系统正在更新中...',
        '新功能已上线，快来体验吧！',
        '数据同步中，请耐心等待',
        '欢迎使用CyberCafe系统'
      ]
    }

    const randomMessage = messages[type][Math.floor(Math.random() * messages[type].length)]
    
    switch (type) {
      case 'success':
        success(randomMessage)
        break
      case 'error':
        error(randomMessage)
        break
      case 'warning':
        warning(randomMessage)
        break
      case 'info':
        info(randomMessage)
        break
    }
  }

  const handleShowMultipleToasts = () => {
    setTimeout(() => success('第一条消息'), 100)
    setTimeout(() => error('第二条错误消息'), 300)
    setTimeout(() => warning('第三条警告消息'), 500)
    setTimeout(() => info('第四条信息消息'), 700)
  }

  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto">
        <h1 
          className="text-3xl font-bold mb-6"
          style={{ color: config.text.title }}
        >
          Toast 提示组件演示
        </h1>
        
        <div 
          className="p-6 rounded-xl shadow-lg mb-6"
          style={{ 
            backgroundColor: config.background.surface,
            border: `1px solid ${config.border.light}`
          }}
        >
          <h2 
            className="text-xl font-semibold mb-4"
            style={{ color: config.text.primary }}
          >
            Toast 功能特性
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div 
              className="p-4 rounded-lg"
              style={{ backgroundColor: config.background.secondary }}
            >
              <h3 
                className="font-semibold mb-2"
                style={{ color: config.text.primary }}
              >
                📱 消息类型
              </h3>
              <ul style={{ color: config.text.secondary }} className="text-sm space-y-1">
                <li>• 成功消息 (绿色)</li>
                <li>• 错误消息 (黄色 - 固定)</li>
                <li>• 警告消息 (红色 - 固定)</li>
                <li>• 信息消息 (蓝色)</li>
              </ul>
            </div>
            
            <div 
              className="p-4 rounded-lg"
              style={{ backgroundColor: config.background.secondary }}
            >
              <h3 
                className="font-semibold mb-2"
                style={{ color: config.text.primary }}
              >
                🎨 视觉效果
              </h3>
              <ul style={{ color: config.text.secondary }} className="text-sm space-y-1">
                <li>• 主题自适应颜色</li>
                <li>• 快速浮现动画</li>
                <li>• 平滑淡出效果</li>
                <li>• 队列叠加显示</li>
              </ul>
            </div>
          </div>

          <h3 
            className="font-semibold mb-3"
            style={{ color: config.text.primary }}
          >
            🚀 测试按钮
          </h3>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
            <button
              onClick={() => handleShowToast('success')}
              className="px-4 py-2 rounded-lg text-white font-medium transition-all duration-200 hover:scale-105 active:scale-95"
              style={{ backgroundColor: '#48BB78' }}
            >
              ✅ 成功消息
            </button>
            
            <button
              onClick={() => handleShowToast('error')}
              className="px-4 py-2 rounded-lg text-white font-medium transition-all duration-200 hover:scale-105 active:scale-95"
              style={{ backgroundColor: '#F59E0B' }}
            >
              ❌ 错误消息
            </button>
            
            <button
              onClick={() => handleShowToast('warning')}
              className="px-4 py-2 rounded-lg text-white font-medium transition-all duration-200 hover:scale-105 active:scale-95"
              style={{ backgroundColor: '#EF4444' }}
            >
              ⚠️ 警告消息
            </button>
            
            <button
              onClick={() => handleShowToast('info')}
              className="px-4 py-2 rounded-lg text-white font-medium transition-all duration-200 hover:scale-105 active:scale-95"
              style={{ backgroundColor: '#4299E1' }}
            >
              ℹ️ 信息消息
            </button>
          </div>

          <div className="flex gap-3">
            <button
              onClick={handleShowMultipleToasts}
              className="px-6 py-2 rounded-lg text-white font-medium transition-all duration-200 hover:scale-105 active:scale-95"
              style={{ 
                background: config.gradient.primary 
              }}
            >
              🎭 显示多条消息
            </button>
            
            <button
              onClick={toggleTheme}
              className="px-6 py-2 rounded-lg text-white font-medium transition-all duration-200 hover:scale-105 active:scale-95"
              style={{ 
                background: config.gradient.primary 
              }}
            >
              🌓 切换主题
            </button>
          </div>
        </div>

        <div 
          className="p-6 rounded-xl shadow-lg"
          style={{ 
            backgroundColor: config.background.surface,
            border: `1px solid ${config.border.light}`
          }}
        >
          <h2 
            className="text-xl font-semibold mb-4"
            style={{ color: config.text.primary }}
          >
            📖 使用说明
          </h2>
          
          <div 
            className="p-4 rounded-lg font-mono text-sm"
            style={{ 
              backgroundColor: config.background.input,
              color: config.text.contrast
            }}
          >
            <pre>{`import { useToast } from '@/components/ui'

const { success, error, warning, info } = useToast()

// 使用方法
success('操作成功！')
error('网络错误！')
warning('请注意！')
info('系统提示！')`}</pre>
          </div>
          
          <p 
            className="mt-4 text-sm"
            style={{ color: config.text.secondary }}
          >
            💡 打开浏览器开发者工具查看Console日志输出，错误和警告消息会自动记录到控制台。
          </p>
        </div>
      </div>
    </MainLayout>
  )
}