import { Theme } from './types'

// 日间模式配置 - 白桃色/樱花色/橘色为主
export const lightTheme: Theme = {
  name: 'Light Theme',
  type: 'light',
  colors: {
    // 背景色系列 - 10种不同用途的背景色
    background: {
      primary: '#FFDCDC',        // 主背景色 - 温暖的白色偏桃色
      secondary: '#FFB48E',       // 次要背景色 - 暖橘色, 建议用于按钮背景
      accent: '#FF9090',          // 强调背景色 - 暖樱色
      surface: '#FFF5F5',         // 表面/卡片背景色 - 淡桃色
      overlay: 'rgba(255, 235, 205, 0.5)', // 遮罩背景色 - 半透明桃色
      input: '#FFFBF8',          // 输入框背景色 - 极浅桃色
      button: 'linear-gradient(135deg, #FFB6C1, #FFA500)', // 按钮背景色 - 樱花橘渐变
      success: '#E8F5E8',         // 成功状态背景色 - 淡绿色
      warning: '#FFF3E0',        // 警告状态背景色 - 淡橘色
      error: '#FFEBEE',          // 错误状态背景色 - 淡红色
    },

    // 文字色系列 - 10种不同用途的文字色
    text: {
      primary: '#2D3748',         // 主要文字色 - 深灰色
      secondary: '#4A5568',       // 次要文字色 - 中灰色
      title: '#1A202C',           // 标题文字色 - 极深灰色
      contrast: '#000000',        // 高对比度文字色 - 纯黑色
      muted: '#718096',           // 弱化文字色 - 浅灰色
      inverse: '#FFFFFF',         // 反色文字色 - 白色
      link: '#FF6B6B',            // 链接文字色 - 桃红色
      placeholder: '#A0AEC0',      // 占位符文字色 - 灰蓝色
      code: '#E53E3E',            // 代码文字色 - 红色
      caption: '#718096',         // 说明文字色 - 浅灰色
    },

    // 边框色系列
    border: {
      light: '#FED7D7',           // 浅边框色 - 淡桃色
      medium: '#FEB2B2',          // 中等边框色 - 桃色
      dark: '#FC8181',            // 深边框色 - 深桃色
      focus: '#FF69B4',           // 焦点边框色 - 热粉色
      error: '#E53E3E',           // 错误边框色 - 红色
      success: '#38A169',          // 成功边框色 - 绿色
    },

    // 渐变色系列
    gradient: {
      primary: 'linear-gradient(135deg, #FFB6C1, #FFA07A, #FFD700)', // 主渐变色 - 樱花橘金
      secondary: 'linear-gradient(135deg, #FFE4E1, #FFF0F5)', // 次要渐变色 - 桃色系
      accent: 'linear-gradient(135deg, #FF69B4, #FF1493)',    // 强调渐变色 - 深粉色系
      night: 'linear-gradient(135deg, #FFB6C1, #FFA07A)',     // 夜间渐变色 - 暖色系
      background: 'linear-gradient(135deg, #FFFAF5, #FFF5F0, #FFE5D9)', // 背景渐变色
    },

    // 阴影色系列
    shadow: {
      light: 'rgba(255, 182, 193, 0.1)',      // 浅阴影 - 樱花色
      medium: 'rgba(255, 182, 193, 0.2)',     // 中等阴影
      dark: 'rgba(255, 182, 193, 0.3)',       // 深阴影
      colored: 'rgba(255, 105, 180, 0.25)',    // 彩色阴影 - 热粉色
    },

    // 状态色系列
    status: {
      info: '#4299E1',          // 信息色 - 蓝色
      success: '#48BB78',       // 成功色 - 绿色
      warning: '#ED8936',       // 警告色 - 橘色
      error: '#F56565',         // 错误色 - 红色
      loading: '#9F7AEA',       // 加载色 - 紫色
    }
  }
}