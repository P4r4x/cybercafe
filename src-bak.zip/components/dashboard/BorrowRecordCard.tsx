import React, { useState, useEffect } from 'react'
import { useThemeConfig } from '@/themes/hooks'
import { useApi } from '@/hooks/useApi'
import { Book, Clock, AlertTriangle, CheckCircle } from 'lucide-react'

// 借阅记录接口
interface BorrowRecord {
  book_id: string
  title: string
  borrow_at: string
  due_at: string
  return_at?: string
}

// 借阅统计接口
interface BorrowStats {
  current: number
  limit: number
}

// 借阅记录卡片组件的Props
interface BorrowRecordCardProps {
  stats: BorrowStats
}

export const BorrowRecordCard: React.FC<BorrowRecordCardProps> = ({ stats }) => {
  const { colors } = useThemeConfig()
  const { get } = useApi()
  const [showRecords, setShowRecords] = useState(false)
  const [records, setRecords] = useState<BorrowRecord[]>([])
  const [filter, setFilter] = useState<'all' | 'unreturned' | 'returned'>('all')
  const [isLoading, setIsLoading] = useState(false)

  // 获取借阅记录
  const fetchRecords = async () => {
    setIsLoading(true)
    try {
      const data = await get<{records: BorrowRecord[]}>('/me/recent_book_records')
      setRecords(data.records || [])
    } catch (error) {
      console.error('Failed to fetch records:', error)
      // useApi已经处理了错误提示和401跳转
    } finally {
      setIsLoading(false)
    }
  }

  // 打开记录弹窗
  const handleShowRecords = () => {
    setShowRecords(true)
    fetchRecords()
  }

  // 计算剩余额度
  const remaining = stats.limit - stats.current
  const remainingPercent = (remaining / stats.limit) * 100

  // 过滤记录
  const filteredRecords = records.filter(record => {
    if (filter === 'unreturned') return !record.return_at
    if (filter === 'returned') return !!record.return_at
    return true
  })

  // 检查是否过期
  const isOverdue = (dueAt: string) => {
    return new Date(dueAt) < new Date()
  }

  // 检查是否3天内到期
  const isDueSoon = (dueAt: string) => {
    const due = new Date(dueAt)
    const now = new Date()
    const diffDays = (due.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
    return diffDays <= 3 && diffDays > 0
  }

  // 获取记录文字颜色
  const getRecordTextColor = (record: BorrowRecord) => {
    if (!record.return_at) {
      if (isOverdue(record.due_at)) return '#EF4444' // 红色 - 已过期
      if (isDueSoon(record.due_at)) return '#F59E0B' // 黄色 - 3天内到期
      return colors.contrast // 正常颜色
    }
    return colors.muted // 已归还 - 灰色
  }

  // 格式化日期
  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('zh-CN')
  }

  return (
    <>
      {/* 借阅记录卡片 */}
      <div 
        className="p-6 rounded-xl shadow-lg cursor-pointer transition-all duration-200 hover:shadow-xl hover:scale-[1.02]"
        style={{ 
          backgroundColor: colors.card,
          border: `1px solid ${colors.border}`
        }}
        onClick={handleShowRecords}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 
            className="font-semibold flex items-center gap-2"
            style={{ color: colors.primary }}
          >
            <Book className="w-5 h-5" />
            借阅记录
          </h3>
          <span 
            className="text-sm px-3 py-1 rounded-full"
            style={{ 
              backgroundColor: colors.input,
              color: colors.secondary
            }}
          >
            {stats.current}/{stats.limit}
          </span>
        </div>

        {/* 剩余额度进度条 */}
        <div className="mb-3">
          <div className="flex justify-between text-sm mb-1">
            <span style={{ color: colors.secondary }}>剩余额度</span>
            <span style={{ color: colors.contrast }}>{remaining}/{stats.limit}</span>
          </div>
          <div 
            className="w-full h-2 rounded-full overflow-hidden"
            style={{ backgroundColor: colors.input }}
          >
            <div 
              className="h-full transition-all duration-300"
              style={{ 
                width: `${remainingPercent}%`,
                backgroundColor: remainingPercent > 3 ? '#48BB78' : remainingPercent > 0 ? '#F59E0B' : '#EF4444'
              }}
            />
          </div>
        </div>

        {/* Hover提示 */}
        <p style={{ color: colors.secondary }} className="text-sm">
          点击查看借阅记录
        </p>
      </div>

      {/* 借阅记录弹窗 */}
      {showRecords && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div 
            className="w-full max-w-2xl max-h-[80vh] m-4 rounded-2xl shadow-2xl overflow-hidden"
            style={{ backgroundColor: colors.card }}
          >
            {/* 弹窗头部 */}
            <div 
              className="p-6 border-b flex justify-between items-center"
              style={{ borderColor: colors.border }}
            >
              <h2 style={{ color: colors.title }} className="text-xl font-semibold">
                借阅记录
              </h2>
              <button
                onClick={() => setShowRecords(false)}
                className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              >
                <span style={{ color: colors.secondary }}>✕</span>
              </button>
            </div>

            {/* 筛选标签 */}
            <div className="p-6 pb-0">
              <div className="flex gap-2">
                <button
                  onClick={() => setFilter('all')}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    filter === 'all' 
                      ? 'text-white' 
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                  style={{ 
                    backgroundColor: filter === 'all' ? '#4299E1' : colors.input 
                  }}
                >
                  全部 ({records.length})
                </button>
                <button
                  onClick={() => setFilter('unreturned')}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    filter === 'unreturned' 
                      ? 'text-white' 
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                  style={{ 
                    backgroundColor: filter === 'unreturned' ? '#EF4444' : colors.input 
                  }}
                >
                  未归还 ({records.filter(r => !r.return_at).length})
                </button>
                <button
                  onClick={() => setFilter('returned')}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    filter === 'returned' 
                      ? 'text-white' 
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                  style={{ 
                    backgroundColor: filter === 'returned' ? '#48BB78' : colors.input 
                  }}
                >
                  已归还 ({records.filter(r => r.return_at).length})
                </button>
              </div>
            </div>

            {/* 记录列表 */}
            <div className="p-6 overflow-y-auto max-h-[50vh]">
              {isLoading ? (
                <div className="text-center py-8">
                  <span style={{ color: colors.secondary }}>加载中...</span>
                </div>
              ) : filteredRecords.length === 0 ? (
                <div className="text-center py-8">
                  <span style={{ color: colors.secondary }}>暂无记录</span>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredRecords.map((record) => (
                    <div 
                      key={record.book_id}
                      className="p-4 rounded-lg border"
                      style={{ 
                        backgroundColor: colors.input,
                        borderColor: colors.border
                      }}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <h4 
                          className="font-medium"
                          style={{ color: colors.primary }}
                        >
                          {record.title}
                        </h4>
                        <div className="flex items-center gap-1 text-xs">
                          {!record.return_at && isOverdue(record.due_at) && (
                            <>
                              <AlertTriangle className="w-3 h-3" />
                              <span style={{ color: '#EF4444' }}>已过期</span>
                            </>
                          )}
                          {!record.return_at && isDueSoon(record.due_at) && (
                            <>
                              <Clock className="w-3 h-3" />
                              <span style={{ color: '#F59E0B' }}>即将到期</span>
                            </>
                          )}
                          {record.return_at && (
                            <>
                              <CheckCircle className="w-3 h-3" />
                              <span style={{ color: colors.muted }}>已归还</span>
                            </>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex justify-between text-sm">
                        <span style={{ color: colors.secondary }}>
                          借阅: {formatDate(record.borrow_at)}
                        </span>
                        <span style={{ color: getRecordTextColor(record) }}>
                          {record.return_at 
                            ? `归还: ${formatDate(record.return_at)}`
                            : `到期: ${formatDate(record.due_at)}`
                          }
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  )
}