import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { Theme, ThemeContextType, ThemePreset } from './types'
import { lightTheme } from './light'
import { darkTheme } from './dark'

// 主题上下文
const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

// 主题Provider组件的Props接口
interface ThemeProviderProps {
  children: ReactNode
  defaultTheme?: ThemePreset
}

// 主题Provider组件
export const ThemeProvider: React.FC<ThemeProviderProps> = ({ 
  children, 
  defaultTheme = 'light' 
}) => {
  // 从localStorage读取保存的主题设置
  const getSavedTheme = (): Theme => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('cybercafe-theme')
      if (saved === 'dark') return darkTheme
      if (saved === 'light') return lightTheme
    }
    return defaultTheme === 'dark' ? darkTheme : lightTheme
  }

  const [theme, setThemeState] = useState<Theme>(getSavedTheme)
  const [isDark, setIsDark] = useState(theme.type === 'dark')

  // 检测系统主题偏好
  const getSystemTheme = (): 'light' | 'dark' => {
    if (typeof window !== 'undefined' && window.matchMedia) {
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
    }
    return 'light'
  }

  // 切换主题
  const toggleTheme = () => {
    const newTheme = theme.type === 'light' ? darkTheme : lightTheme
    setTheme(newTheme)
  }

  // 设置指定主题
  const setTheme = (newTheme: Theme) => {
    setThemeState(newTheme)
    setIsDark(newTheme.type === 'dark')
    
    // 保存到localStorage
    if (typeof window !== 'undefined') {
      localStorage.setItem('cybercafe-theme', newTheme.type)
    }

    // 更新HTML根元素的data-theme属性
    if (typeof document !== 'undefined') {
      document.documentElement.setAttribute('data-theme', newTheme.type)
      document.documentElement.style.colorScheme = newTheme.type
    }
  }

  // 自动主题（跟随系统）
  const setAutoTheme = () => {
    const systemTheme = getSystemTheme()
    const autoTheme = systemTheme === 'dark' ? darkTheme : lightTheme
    setTheme(autoTheme)
  }

  // 初始化主题
  useEffect(() => {
    const savedTheme = getSavedTheme()
    setTheme(savedTheme)
  }, [])

  // 监听系统主题变化
  useEffect(() => {
    if (typeof window !== 'undefined' && window.matchMedia) {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)')
      const handleChange = (e: MediaQueryListEvent) => {
        const currentTheme = localStorage.getItem('cybercafe-theme')
        if (currentTheme === 'auto') {
          setTheme(e.matches ? darkTheme : lightTheme)
        }
      }

      mediaQuery.addEventListener('change', handleChange)
      return () => mediaQuery.removeEventListener('change', handleChange)
    }
  }, [])

  // 生成CSS变量
  useEffect(() => {
    if (typeof document !== 'undefined') {
      const root = document.documentElement
      
      // 设置所有颜色CSS变量
      const setCSSVariables = (colors: any, prefix: string = '') => {
        Object.entries(colors).forEach(([key, value]) => {
          const cssVar = `--theme-${prefix}${key}`
          if (typeof value === 'string') {
            root.style.setProperty(cssVar, value)
          } else if (typeof value === 'object') {
            setCSSVariables(value, `${prefix}${key}-`)
          }
        })
      }

      setCSSVariables(theme.colors)
    }
  }, [theme])

  const value: ThemeContextType = {
    theme,
    isDark,
    toggleTheme,
    setTheme
  }

  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  )
}

// 使用主题的Hook
export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext)
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider')
  }
  return context
}

// 导出主题实例
export { lightTheme, darkTheme }