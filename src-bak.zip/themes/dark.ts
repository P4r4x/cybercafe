import { Theme } from './types'

// 夜间模式配置 - 夜樱/深蓝/深紫色为主
export const darkTheme: Theme = {
  name: 'Dark Theme',
  type: 'dark',
  colors: {
    // 背景色系列 - 10种不同用途的背景色
    background: {
      primary: '#1A1F2E',        // 主背景色 - 深蓝黑色
      secondary: '#2D3748',       // 次要背景色 - 深灰色
      accent: '#4A5568',          // 强调背景色 - 中深灰色
      surface: '#2D3548',         // 表面/卡片背景色 - 深紫灰色
      overlay: 'rgba(26, 31, 46, 0.8)', // 遮罩背景色 - 半透明深蓝
      input: '#1E2533',          // 输入框背景色 - 极深蓝黑
      button: 'linear-gradient(135deg, #667EEA, #764BA2, #F093FB)', // 按钮背景色 - 紫蓝渐变
      success: '#1A3D1A',         // 成功状态背景色 - 深绿色
      warning: '#3D2D1A',        // 警告状态背景色 - 深橘色
      error: '#3D1A1A',          // 错误状态背景色 - 深红色
    },

    // 文字色系列 - 10种不同用途的文字色
    text: {
      primary: '#E2E8F0',         // 主要文字色 - 浅灰白色
      secondary: '#CBD5E0',       // 次要文字色 - 中浅灰色
      title: '#F7FAFC',           // 标题文字色 - 近白色
      contrast: '#FFFFFF',        // 高对比度文字色 - 纯白色
      muted: '#718096',           // 弱化文字色 - 中灰色
      inverse: '#1A202C',         // 反色文字色 - 深色
      link: '#B794F4',            // 链接文字色 - 淡紫色
      placeholder: '#4A5568',      // 占位符文字色 - 深灰色
      code: '#FC8181',            // 代码文字色 - 淡红色
      caption: '#A0AEC0',         // 说明文字色 - 中浅灰色
    },

    // 边框色系列
    border: {
      light: '#4A5568',           // 浅边框色 - 中深灰色
      medium: '#718096',          // 中等边框色 - 中灰色
      dark: '#A0AEC0',            // 深边框色 - 中浅灰色
      focus: '#B794F4',           // 焦点边框色 - 紫色
      error: '#FC8181',           // 错误边框色 - 淡红色
      success: '#68D391',         // 成功边框色 - 淡绿色
    },

    // 渐变色系列
    gradient: {
      primary: 'linear-gradient(135deg, #667EEA, #764BA2, #F093FB)', // 主渐变色 - 紫蓝粉
      secondary: 'linear-gradient(135deg, #2D3748, #4A5568)', // 次要渐变色 - 深灰系
      accent: 'linear-gradient(135deg, #9F7AEA, #B794F4, #D6BCFA)', // 强调渐变色 - 深紫色系
      night: 'linear-gradient(135deg, #1A1F2E, #2D1B69, #4C1D95)', // 夜间渐变色 - 夜樱深蓝深紫
      background: 'linear-gradient(135deg, #1A1F2E, #2D3748, #4A5568)', // 背景渐变色
    },

    // 阴影色系列
    shadow: {
      light: 'rgba(31, 41, 55, 0.3)',         // 浅阴影 - 深灰色
      medium: 'rgba(31, 41, 55, 0.5)',        // 中等阴影
      dark: 'rgba(31, 41, 55, 0.7)',          // 深阴影
      colored: 'rgba(159, 122, 234, 0.4)',      // 彩色阴影 - 紫色
    },

    // 状态色系列
    status: {
      info: '#63B3ED',          // 信息色 - 淡蓝色
      success: '#68D391',       // 成功色 - 淡绿色
      warning: '#F6AD55',       // 警告色 - 淡橘色
      error: '#FC8181',         // 错误色 - 淡红色
      loading: '#B794F4',        // 加载色 - 淡紫色
    }
  }
}