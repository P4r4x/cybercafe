import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useTheme } from '@/themes'
import { Avatar } from '@/components/ui/SmartImage'
import {
  Home,
  Search,
  BookOpen,
  ShoppingCart,
  User,
  Sun,
  Moon,
  ChevronRight
} from 'lucide-react'

// 用户信息接口
interface UserInfo {
  avatar: string
  username: string
  userId: string
}

// 导航菜单项接口
interface NavItem {
  id: string
  label: string
  icon: React.ComponentType<any>
  active?: boolean
}

export const Sidebar: React.FC = () => {
  // 一次性从 useTheme 取到需要的值
  const { isDark, toggleTheme } = useTheme()
  const navigate = useNavigate()
  const [isExpanded, setIsExpanded] = useState(false)

  // 用户信息（从 localStorage 读取的逻辑保留）
  const [userInfo] = useState<UserInfo>(() => {
    if (typeof window !== 'undefined') {
      const userStr = localStorage.getItem('cybercafe_user')
      if (userStr) {
        try {
          const user = JSON.parse(userStr)
          return {
            avatar: user.avatar || '/api/placeholder/40/40',
            username: user.username || 'CyberUser',
            userId: `ID: ${user.id || '2024001'}`
          }
        } catch (e) {}
      }
    }
    return {
      avatar: '/api/placeholder/40/40',
      username: 'CyberUser',
      userId: 'ID: 2024001'
    }
  })

  const navItems: NavItem[] = [
    { id: 'home', label: '主页', icon: Home, active: true },
    { id: 'search', label: '搜书', icon: Search },
    { id: 'bookshelf', label: '书架', icon: BookOpen },
    { id: 'orders', label: '订单', icon: ShoppingCart },
    { id: 'member', label: '会员中心', icon: User }
  ]

  return (
    <div
      // 不使用 transition-all —— 只在内联 style 上对 width 做过渡
      className="fixed left-0 top-0 h-full z-50"
      style={{
        // 宽度动画用内联 style（更可靠）
        width: isExpanded ? 240 : 64,
        transition: 'width 300ms ease',
        // 阴影仍然跟随展开/收起（直接切换样式即可）
        boxShadow: isExpanded
          ? '4px 0 20px rgba(109, 40, 217, 0.3)'
          : '2px 0 12px rgba(109, 40, 217, 0.2)'
      }}
      onMouseEnter={() => setIsExpanded(true)}
      onMouseLeave={() => setIsExpanded(false)}
    >
      {/* 背景图层容器（相对定位以承载绝对背景层） */}
      <div className="relative h-full">
        {/* Dark 背景层 */}
        <div
          aria-hidden
          className={`absolute inset-0 pointer-events-none transition-opacity duration-500`}
          style={{
            // 当 isDark 为 true 时，dark 层完全可见；否则透明
            opacity: isDark ? 1 : 0
          }}
        >
          {/* 你可以把下面的 Tailwind 类改为任意线性渐变或者自定义 bg-[...] */}
          <div className="w-full h-full bg-gradient-to-b from-purple-900 via-purple-700 to-pink-900" />
        </div>

        {/* Light 背景层 */}
        <div
          aria-hidden
          className={`absolute inset-0 pointer-events-none transition-opacity duration-500`}
          style={{
            // Light 层与 Dark 层反向淡入淡出
            opacity: isDark ? 0 : 1
          }}
        >
          <div className="w-full h-full bg-gradient-to-b from-[#faada0] to-[#ffb68f]" />
        </div>

        {/* 内容（放在最上层） */}
        <div className="h-full flex flex-col py-4 relative">
          {/* 用户信息区域 */}
          <div className="px-4 mb-6">
            <div className="flex items-center space-x-3">
              <div
                className="flex-shrink-0 transition-transform duration-300"
                style={{
                  transform: isExpanded ? 'scale(1.2)' : 'scale(1)'
                }}
              >
                <Avatar
                  src={userInfo.avatar}
                  alt="用户头像"
                  width={40}
                  height={40}
                />
              </div>

              {/* 用户信息文字 - 展开时显示 */}
              <div
                className="overflow-hidden transition-opacity duration-300"
                style={{
                  opacity: isExpanded ? 1 : 0,
                  maxWidth: isExpanded ? 150 : 0,
                  transform: isExpanded ? 'translateX(0)' : 'translateX(-8px)'
                }}
              >
                {/* 关键：文字颜色使用 transition-colors，让颜色平滑但不会与布局混合 */}
                <div
                  className={`font-semibold text-sm truncate transition-colors duration-300 ${
                    isDark ? 'text-white' : 'text-orange-800'
                  }`}
                >
                  {userInfo.username}
                </div>
                <div
                  className={`text-xs truncate transition-colors duration-300 ${
                    isDark ? 'text-white/80' : 'text-orange-800/80'
                  }`}
                >
                  {userInfo.userId}
                </div>
              </div>
            </div>
          </div>

          {/* 分割线 */}
          <div className="px-4 mb-4">
            <div
              className="h-px transition-opacity duration-300"
              style={{
                background: 'rgba(255,255,255,0.3)',
                opacity: isExpanded ? 1 : 0.6
              }}
            />
          </div>

          {/* 导航菜单 */}
          <nav className="flex-1 px-2">
            <ul className="space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon
                const isActive = item.active

                return (
                  <li key={item.id}>
                    <button
                      onClick={() => {
                        if (item.id === 'home') {
                          navigate('/home')
                        } else if (item.id === 'search') {
                          navigate('/searchbook')
                        } else if (item.id === 'bookshelf') {
                          navigate('/bookshelf')
                        } else {
                          navigate('/home')
                        }
                      }}
                      className={`w-full flex items-center px-3 py-2.5 rounded-xl transition-transform duration-200 group ${
                        isActive
                          ? `shadow-sm`
                          : `font-medium hover:scale-[1.01]`
                      }`}
                      // 不要在这里使用 transition-all 来避免颜色被 layout 动画污染
                    >
                      {/* 图标 */}
                      <div className="flex-shrink-0">
                        <Icon
                          size={20}
                          // 图标颜色也随主题变换
                          className={`transition-colors duration-300 ${
                            isDark ? 'text-white' : 'text-orange-800'
                          }`}
                        />
                      </div>

                      {/* 文字标签 */}
                      <div
                        className="ml-3 overflow-hidden transition-all duration-300 whitespace-nowrap"
                        style={{
                          opacity: isExpanded ? 1 : 0,
                          maxWidth: isExpanded ? 120 : 0,
                          transform: isExpanded ? 'translateX(0)' : 'translateX(-8px)'
                        }}
                      >
                        <span
                          className={`text-sm font-semibold transition-colors duration-300 ${
                            isActive
                              ? isDark
                                ? 'text-white'
                                : 'text-orange-800'
                              : isDark
                              ? 'text-white'
                              : 'text-orange-800/80'
                          }`}
                        >
                          {item.label}
                        </span>
                      </div>

                      {/* 活跃状态指示器 */}
                      {isActive && isExpanded && (
                        <ChevronRight
                          size={16}
                          className="ml-auto transition-colors duration-300 text-white/60"
                        />
                      )}
                    </button>
                  </li>
                )
              })}
            </ul>
          </nav>

          {/* 主题切换按钮 */}
          <div className="px-2 mt-auto">
            <button
              onClick={toggleTheme}
              className="w-full flex items-center px-3 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 transition-colors duration-200 group"
            >
              <div className="flex-shrink-0">
                {isDark ? (
                  <Sun size={20} className="transition-colors duration-300 text-white/90" />
                ) : (
                  <Moon size={20} className="transition-colors duration-300 text-orange-800/90" />
                )}
              </div>

              <div
                className="ml-3 overflow-hidden transition-opacity duration-300 whitespace-nowrap"
                style={{
                  opacity: isExpanded ? 1 : 0,
                  maxWidth: isExpanded ? 120 : 0,
                  transform: isExpanded ? 'translateX(0)' : 'translateX(-8px)'
                }}
              >
                <span className={`text-sm font-medium transition-colors duration-300 ${isDark ? 'text-white' : 'text-orange-800'}`}>
                  {isDark ? '日间模式' : '夜间模式'}
                </span>
              </div>
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
