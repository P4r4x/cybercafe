import React from 'react'
import { MainLayout } from '@/components/layout'
import { useThemeConfig } from '@/themes/hooks'
import { BookshelfGrid } from '@/components/bookshelf'
import { BookshelfItemDTO } from '@/types/bookshelf'
import { useNavigate } from 'react-router-dom'

export default function BookshelfPage() {
  const { config } = useThemeConfig()
  const navigate = useNavigate()

  const handleBookClick = (book: BookshelfItemDTO) => {
    navigate(`/book-detail/${book.BookID}`)
  }

  return (
    <MainLayout>
      <div className="relative min-h-screen bg-[#ffe5e0] dark:bg-[#3c0042] overflow-hidden">
        <div className="pointer-events-none absolute inset-0 bg-moving-grid" />
        
        <div className="relative z-10">
          <div className="max-w-6xl mx-auto p-6">
            <BookshelfGrid onBookClick={handleBookClick} />
          </div>
        </div>
      </div>
    </MainLayout>
  )
}